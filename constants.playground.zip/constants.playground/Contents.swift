//: Playground - noun: a place where people can play

import UIKit

// Sabitler - Constants 

/* Sabit değer atama şablonu

let <#name#> = <#value#>

 let : Sabit bir değer olacağını,
 name : Sabite verilecek ismi,
 = : Değer atanacağını,
 value : Değerini ifade eder.
 */

// "name" isimli bir sabite "Can" değerini atayalım ve print konsolunda yazdıralım
let name = "Can"
print(name)
//veya şöyle de yazabilirsiniz
name

// "soyadi" isimli bir sabite "Can" değerini atayalım ve daha sonra "Aydın" değeri ile değiştirmeyi deneyelim
var soyadi = "Can"
soyadi = "Aydın"

// Sabit değer atamaya örnekler
let sayi = 10
print(sayi)

let pi = 3.14
print(pi)

let kullaniciAdi = "Aydın CAN"
print(kullaniciAdi)
